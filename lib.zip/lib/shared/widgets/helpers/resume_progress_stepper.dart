import 'package:flutter/material.dart';
import 'package:vitafolio/app/constants/app_colors.dart';
import 'package:vitafolio/app/constants/app_spacing.dart';

/// Vitafolio v2.0 Resume Progress Stepper (9 Steps) reading colors from ThemeData
class ResumeProgressStepper extends StatelessWidget {
  final int currentStep; // 1-indexed (1 to 9)
  final ValueChanged<int>? onStepTapped;

  static const List<String> stepLabels = [
    'Template',
    'Personal',
    'Summary',
    'Experience',
    'Education',
    'Skills',
    'Certifications',
    'Languages',
    'Preview',
  ];

  const ResumeProgressStepper({
    super.key,
    required this.currentStep,
    this.onStepTapped,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final activeIndex = (currentStep - 1).clamp(0, stepLabels.length - 1);

    return Container(
      color: theme.scaffoldBackgroundColor,
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Step Counter Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'STEP $currentStep OF ${stepLabels.length}',
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: colorScheme.primary,
                    letterSpacing: 1.0,
                  ),
                ),
                Text(
                  stepLabels[activeIndex],
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onSurface,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.sm),

          // Stepper List
          SizedBox(
            height: 36,
            child: ScrollConfiguration(
              behavior: ScrollConfiguration.of(context).copyWith(scrollbars: false),
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                itemCount: stepLabels.length,
                separatorBuilder: (_, index) => const SizedBox(width: AppSpacing.sm),

                itemBuilder: (context, index) {
                  final isCompleted = index < activeIndex;
                  final isActive = index == activeIndex;

                  Color circleBg;
                  Color textColor;
                  Widget iconOrDot;

                  if (isCompleted) {
                    circleBg = AppColors.success;
                    textColor = colorScheme.onSurface;
                    iconOrDot = Icon(Icons.check_rounded, size: 14, color: colorScheme.onPrimary);
                  } else if (isActive) {
                    circleBg = colorScheme.primary;
                    textColor = colorScheme.primary;
                    iconOrDot = Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: colorScheme.onPrimary,
                        shape: BoxShape.circle,
                      ),
                    );
                  } else {
                    circleBg = colorScheme.outline;
                    textColor = colorScheme.onSurfaceVariant;
                    iconOrDot = Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: colorScheme.surface,
                        shape: BoxShape.circle,
                      ),
                    );
                  }

                  return GestureDetector(
                    onTap: () {
                      if (onStepTapped != null) {
                        onStepTapped!(index + 1);
                      }
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: isActive ? colorScheme.primaryContainer : Colors.transparent,
                        borderRadius: BorderRadius.circular(AppSpacing.radiusChip),
                        border: Border.all(
                          color: isActive ? colorScheme.primary : Colors.transparent,
                          width: 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 20,
                            height: 20,
                            decoration: BoxDecoration(
                              color: circleBg,
                              shape: BoxShape.circle,
                            ),
                            alignment: Alignment.center,
                            child: iconOrDot,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            stepLabels[index],
                            style: TextStyle(
                              fontFamily: 'Inter',
                              fontSize: 13,
                              fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                              color: textColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
