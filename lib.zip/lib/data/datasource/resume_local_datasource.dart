class ResumeLocalDataSource {
  const ResumeLocalDataSource();
}
