import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:vitafolio/core/templates/models/resume_template.dart' as core;
import 'package:vitafolio/features/templates/widgets/template_thumbnail.dart';
import 'package:vitafolio/features/templates/widgets/template_badge.dart';
import 'package:vitafolio/features/templates/widgets/selected_badge.dart';
import 'package:vitafolio/features/templates/widgets/use_template_button.dart';
import 'package:vitafolio/app/constants/app_spacing.dart';
import 'package:vitafolio/app/router.dart';

class TemplateCard extends ConsumerWidget {
  final core.ResumeTemplate template;
  final bool isSelected;

  const TemplateCard({
    super.key,
    required this.template,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: isSelected ? 4 : 1,
      color: colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: isSelected
            ? BorderSide(color: colorScheme.primary, width: 2)
            : BorderSide(color: theme.dividerColor, width: 1),
      ),
      child: InkWell(
        onTap: () =>
            context.pushNamed(AppRoutes.templatePreview, extra: template),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: Stack(
                children: [
                  TemplateThumbnail(
                    template: template,
                    heroTag: 'template_${template.id}',
                  ),
                  if (isSelected)
                    const Positioned(top: 8, right: 8, child: SelectedBadge()),
                  if (template.category == core.TemplateCategory.ats)
                    const Positioned(top: 8, left: 8, child: TemplateBadge()),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.sm,
                AppSpacing.sm,
                AppSpacing.sm,
                0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    template.name,
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    template.category.label,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colorScheme.secondary,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(AppSpacing.sm),
              child: isSelected
                  ? OutlinedButton.icon(
                      onPressed: null,
                      icon: const Icon(Icons.check, size: 16),
                      label: const Text('Selected'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        minimumSize: Size.zero,
                      ),
                    )
                  : UseTemplateButton(templateId: template.id),
            ),
          ],
        ),
      ),
    );
  }
}
