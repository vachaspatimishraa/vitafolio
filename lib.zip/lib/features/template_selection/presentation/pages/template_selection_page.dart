import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:vitafolio/app/constants/app_spacing.dart';
import 'package:vitafolio/app/router.dart';
import 'package:vitafolio/features/template_selection/presentation/viewmodels/template_selection_viewmodel.dart';
import 'package:vitafolio/features/template_selection/presentation/widgets/resume_progress_stepper.dart';
import 'package:vitafolio/features/template_selection/presentation/widgets/selected_template_card.dart';
import 'package:vitafolio/features/template_selection/presentation/widgets/template_card.dart';
import 'package:vitafolio/features/template_selection/presentation/widgets/template_grid.dart';
import 'package:vitafolio/features/template_selection/presentation/widgets/template_preview_dialog.dart';

/// Screen for choosing a resume template matching Stitch design.
class TemplateSelectionPage extends ConsumerWidget {
  const TemplateSelectionPage({super.key});

  void _handleSelectTemplate(WidgetRef ref, MockTemplate template) {
    ref.read(templateSelectionViewModelProvider.notifier).selectTemplate(template.id);
  }

  void _handleShowPreview(BuildContext context, WidgetRef ref, MockTemplate template) {
    final state = ref.read(templateSelectionViewModelProvider);
    showDialog(
      context: context,
      builder: (context) => TemplatePreviewDialog(
        template: template,
        isSelected: state.selectedTemplateId == template.id,
        onSelect: () => _handleSelectTemplate(ref, template),
      ),
    );
  }

  Future<void> _handleContinue(BuildContext context, WidgetRef ref) async {
    final success = await ref
        .read(templateSelectionViewModelProvider.notifier)
        .saveSelection();
    if (!context.mounted) return;
    if (success) {
      context.push(AppRoutes.personal);
    } else {
      final errorMsg = ref.read(templateSelectionViewModelProvider).errorMessage ?? 'Failed to save template selection';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(errorMsg),
          backgroundColor: Theme.of(context).colorScheme.error,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final state = ref.watch(templateSelectionViewModelProvider);

    MockTemplate? selectedTemplate;
    if (state.selectedTemplateId != null) {
      final matches = kMockTemplates.where((t) => t.id == state.selectedTemplateId);
      if (matches.isNotEmpty) {
        selectedTemplate = matches.first;
      }
    }

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
        title: const Text(
          'Choose Template',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: colorScheme.surface,
        scrolledUnderElevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Divider(
            height: 1,
            color: colorScheme.outlineVariant.withValues(alpha: 0.5),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Resume Progress Stepper
            const ResumeProgressStepper(currentStepIndex: 0),

            // Page Header & Grid Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(AppSpacing.lg),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header Title & Subtitle
                    Text(
                      'Choose Your Resume Template',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      'Select a professional template. You can change it later without losing your information.',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.lg),

                    // Template Grid
                    TemplateGrid(
                      selectedTemplateId: state.selectedTemplateId,
                      onSelect: (template) => _handleSelectTemplate(ref, template),
                      onPreview: (template) => _handleShowPreview(context, ref, template),
                    ),

                    // Selected Template Card (Visible when selected)
                    if (selectedTemplate != null)
                      SelectedTemplateCard(template: selectedTemplate),
                  ],
                ),
              ),
            ),

            // Sticky Bottom Navigation Footer
            Container(
              padding: const EdgeInsets.all(AppSpacing.lg),
              decoration: BoxDecoration(
                color: colorScheme.surface,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 10,
                    offset: const Offset(0, -4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 54,
                      child: OutlinedButton(
                        onPressed: state.isLoading ? null : () => context.pop(),
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          side: BorderSide(color: colorScheme.outline),
                        ),
                        child: Text(
                          'Previous',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: colorScheme.onSurface,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: SizedBox(
                      height: 54,
                      child: ElevatedButton(
                        onPressed: selectedTemplate != null && !state.isLoading
                            ? () => _handleContinue(context, ref)
                            : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: colorScheme.primary,
                          foregroundColor: colorScheme.onPrimary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          disabledBackgroundColor: colorScheme.primary
                              .withValues(alpha: 0.38),
                        ),
                        child: state.isLoading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Continue',
                                    style: theme.textTheme.titleMedium?.copyWith(
                                      fontWeight: FontWeight.w600,
                                      color: selectedTemplate != null
                                          ? colorScheme.onPrimary
                                          : colorScheme.onSurface
                                              .withValues(alpha: 0.38),
                                    ),
                                  ),
                                  const SizedBox(width: AppSpacing.xs),
                                  Icon(
                                    Icons.arrow_forward,
                                    size: 18,
                                    color: selectedTemplate != null
                                        ? colorScheme.onPrimary
                                        : colorScheme.onSurface
                                            .withValues(alpha: 0.38),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
