import 'package:flutter/material.dart';

/// Mock template data model for UI preview state.
class MockTemplate {
  final String id;
  final String name;
  final String description;
  final bool isAtsFriendly;
  final String previewAsset;

  const MockTemplate({
    required this.id,
    required this.name,
    required this.description,
    required this.isAtsFriendly,
    required this.previewAsset,
  });
}

const List<MockTemplate> kMockTemplates = [
  MockTemplate(
    id: 'ats_pro',
    name: 'ATS Professional',
    description: 'Clean single-column layout optimized for ATS scanners.',
    isAtsFriendly: true,
    previewAsset: 'assets/templates/ats_pro.png',
  ),
  MockTemplate(
    id: 'modern',
    name: 'Modern',
    description: 'Sleek design with subtle accents for creative roles.',
    isAtsFriendly: true,
    previewAsset: 'assets/templates/modern.png',
  ),
  MockTemplate(
    id: 'minimal',
    name: 'Minimal',
    description: 'Clutter-free, typographic emphasis for senior pros.',
    isAtsFriendly: false,
    previewAsset: 'assets/templates/minimal.png',
  ),
  MockTemplate(
    id: 'executive',
    name: 'Executive',
    description: 'Structured layout tailored for corporate leadership.',
    isAtsFriendly: true,
    previewAsset: 'assets/templates/executive.png',
  ),
  MockTemplate(
    id: 'creative',
    name: 'Creative',
    description: 'Vibrant sidebar format ideal for designers & marketers.',
    isAtsFriendly: false,
    previewAsset: 'assets/templates/creative.png',
  ),
  MockTemplate(
    id: 'elegant',
    name: 'Elegant',
    description: 'Traditional serif headers with balanced white space.',
    isAtsFriendly: true,
    previewAsset: 'assets/templates/elegant.png',
  ),
];

/// Card widget representing an individual resume template item.
class TemplateCard extends StatelessWidget {
  final MockTemplate template;
  final bool isSelected;
  final VoidCallback onTap;
  final VoidCallback onPreviewTap;

  const TemplateCard({
    super.key,
    required this.template,
    required this.isSelected,
    required this.onTap,
    required this.onPreviewTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final primaryColor = colorScheme.primary;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeInOut,
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSelected ? primaryColor : colorScheme.outlineVariant,
          width: isSelected ? 2.5 : 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: isSelected
                ? primaryColor.withValues(alpha: 0.15)
                : Colors.black.withValues(alpha: 0.04),
            blurRadius: isSelected ? 12 : 6,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Image Thumbnail / Preview Container
              Expanded(
                child: Stack(
                  children: [
                    InkWell(
                      onTap: onPreviewTap,
                      child: Container(
                        width: double.infinity,
                        height: double.infinity,
                        color: colorScheme.surfaceContainerHigh,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.description_outlined,
                              size: 40,
                              color: isSelected
                                  ? primaryColor
                                  : colorScheme.onSurfaceVariant,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'Tap to Preview',
                              style: theme.textTheme.labelSmall?.copyWith(
                                color: colorScheme.onSurfaceVariant,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (template.isAtsFriendly)
                      Positioned(
                        top: 8,
                        left: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: colorScheme.secondaryContainer,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            'ATS Friendly',
                            style: theme.textTheme.labelSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: colorScheme.onSecondaryContainer,
                              fontSize: 10,
                            ),
                          ),
                        ),
                      ),
                    if (isSelected)
                      Positioned(
                        top: 8,
                        right: 8,
                        child: AnimatedScale(
                          scale: isSelected ? 1.0 : 0.0,
                          duration: const Duration(milliseconds: 200),
                          child: Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(
                              color: primaryColor,
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.check,
                              size: 16,
                              color: colorScheme.onPrimary,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),

              // Template Info Section
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      template.name,
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: colorScheme.onSurface,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      template.description,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                        fontSize: 11,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
