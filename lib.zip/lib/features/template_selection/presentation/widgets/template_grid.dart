import 'package:flutter/material.dart';
import 'package:vitafolio/features/template_selection/presentation/widgets/template_card.dart';

/// Grid widget laying out template cards responsively.
class TemplateGrid extends StatelessWidget {
  final String? selectedTemplateId;
  final ValueChanged<MockTemplate> onSelect;
  final ValueChanged<MockTemplate> onPreview;

  const TemplateGrid({
    super.key,
    required this.selectedTemplateId,
    required this.onSelect,
    required this.onPreview,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        int crossAxisCount = 2;
        if (constraints.maxWidth > 900) {
          crossAxisCount = 4;
        } else if (constraints.maxWidth > 600) {
          crossAxisCount = 3;
        }

        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 0.72,
          ),
          itemCount: kMockTemplates.length,
          itemBuilder: (context, index) {
            final template = kMockTemplates[index];
            final isSelected = template.id == selectedTemplateId;

            return TemplateCard(
              template: template,
              isSelected: isSelected,
              onTap: () => onSelect(template),
              onPreviewTap: () => onPreview(template),
            );
          },
        );
      },
    );
  }
}
