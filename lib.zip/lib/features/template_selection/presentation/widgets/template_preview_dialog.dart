import 'package:flutter/material.dart';
import 'package:vitafolio/features/template_selection/presentation/widgets/template_card.dart';

/// Fullscreen A4 template preview dialog.
class TemplatePreviewDialog extends StatelessWidget {
  final MockTemplate template;
  final bool isSelected;
  final VoidCallback onSelect;

  const TemplatePreviewDialog({
    super.key,
    required this.template,
    required this.isSelected,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Dialog(
      insetPadding: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          constraints: BoxConstraints(
            maxWidth: 500,
            maxHeight: MediaQuery.of(context).size.height * 0.85,
          ),
          color: colorScheme.surface,
          child: Column(
            children: [
              // Dialog Header
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            template.name,
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            template.description,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),

              // Mock A4 Page Container
              Expanded(
                child: Container(
                  color: colorScheme.surfaceContainerHigh,
                  padding: const EdgeInsets.all(16),
                  child: Center(
                    child: AspectRatio(
                      aspectRatio: 1 / 1.414, // A4 aspect ratio
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.1),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Header placeholder line
                            Container(
                              height: 16,
                              width: 140,
                              color: Colors.grey.shade400,
                            ),
                            const SizedBox(height: 8),
                            Container(
                              height: 8,
                              width: 200,
                              color: Colors.grey.shade300,
                            ),
                            const SizedBox(height: 20),
                            const Divider(thickness: 1.5),
                            const SizedBox(height: 12),

                            // Mock section 1
                            Container(
                              height: 10,
                              width: 90,
                              color: colorScheme.primary,
                            ),
                            const SizedBox(height: 8),
                            Container(
                              height: 6,
                              width: double.infinity,
                              color: Colors.grey.shade300,
                            ),
                            const SizedBox(height: 4),
                            Container(
                              height: 6,
                              width: double.infinity,
                              color: Colors.grey.shade300,
                            ),
                            const SizedBox(height: 4),
                            Container(
                              height: 6,
                              width: 180,
                              color: Colors.grey.shade300,
                            ),
                            const SizedBox(height: 16),

                            // Mock section 2
                            Container(
                              height: 10,
                              width: 110,
                              color: colorScheme.primary,
                            ),
                            const SizedBox(height: 8),
                            Container(
                              height: 6,
                              width: double.infinity,
                              color: Colors.grey.shade300,
                            ),
                            const SizedBox(height: 4),
                            Container(
                              height: 6,
                              width: 220,
                              color: Colors.grey.shade300,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // Action Footer
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      onSelect();
                      Navigator.of(context).pop();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: colorScheme.primary,
                      foregroundColor: colorScheme.onPrimary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: Icon(isSelected ? Icons.check : Icons.touch_app),
                    label: Text(
                      isSelected ? 'Selected' : 'Use This Template',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
