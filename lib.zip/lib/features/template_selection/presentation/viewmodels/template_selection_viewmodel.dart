import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vitafolio/features/resume/domain/entities/resume.dart';
import 'package:vitafolio/features/resume/domain/usecases/get_resume.dart';
import 'package:vitafolio/features/resume/domain/usecases/update_resume.dart';
import 'package:vitafolio/features/resume/domain/value_objects/resume_id.dart';
import 'package:vitafolio/features/resume/domain/value_objects/template_id.dart';
import 'package:vitafolio/features/resume/presentation/providers/resume_domain_providers.dart';

class TemplateSelectionState {
  final String? selectedTemplateId;
  final bool isLoading;
  final String? errorMessage;

  const TemplateSelectionState({
    this.selectedTemplateId,
    this.isLoading = false,
    this.errorMessage,
  });

  TemplateSelectionState copyWith({
    String? selectedTemplateId,
    bool? isLoading,
    String? errorMessage,
  }) {
    return TemplateSelectionState(
      selectedTemplateId: selectedTemplateId ?? this.selectedTemplateId,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage,
    );
  }
}

class TemplateSelectionViewModel extends StateNotifier<TemplateSelectionState> {
  final Ref _ref;
  final GetResume _getResume;
  final UpdateResume _updateResume;

  TemplateSelectionViewModel(this._ref, this._getResume, this._updateResume)
      : super(const TemplateSelectionState()) {
    _init();
  }

  Future<void> _init() async {
    final activeId = _ref.read(activeResumeIdProvider);
    if (activeId != null) {
      state = state.copyWith(isLoading: true);
      try {
        final resume = await _getResume(activeId);
        if (resume != null) {
          state = state.copyWith(
            selectedTemplateId: resume.selectedTemplateId.value,
            isLoading: false,
          );
        } else {
          state = state.copyWith(isLoading: false);
        }
      } catch (e) {
        state = state.copyWith(
          isLoading: false,
          errorMessage: 'Failed to load template selection',
        );
      }
    }
  }

  void selectTemplate(String templateId) {
    state = state.copyWith(selectedTemplateId: templateId);
  }

  Future<bool> saveSelection() async {
    if (state.selectedTemplateId == null) return false;

    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final activeId = _ref.read(activeResumeIdProvider);
      if (activeId != null && activeId.value.isNotEmpty) {
        final resume = await _getResume(activeId);
        if (resume != null) {
          final updatedResume = resume.copyWith(
            selectedTemplateId: TemplateId(state.selectedTemplateId!),
            updatedAt: DateTime.now(),
          );
          await _updateResume(updatedResume);
          state = state.copyWith(isLoading: false);
          return true;
        }
      }

      // If activeId is not set or resume not found in store, create/persist active resume
      final newResume = await _ref.read(createResumeUseCaseProvider).call(
            Resume(
              id: const ResumeId(''),
              title: 'Untitled Resume',
              selectedTemplateId: TemplateId(state.selectedTemplateId!),
              createdAt: DateTime.now(),
              updatedAt: DateTime.now(),
            ),
          );
      _ref.read(activeResumeIdProvider.notifier).state = newResume.id;
      state = state.copyWith(isLoading: false);
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to save template selection: ${e.toString()}',
      );
      return false;
    }
  }
}

final templateSelectionViewModelProvider =
    StateNotifierProvider<TemplateSelectionViewModel, TemplateSelectionState>(
        (ref) {
  final getResume = ref.watch(getResumeUseCaseProvider);
  final updateResume = ref.watch(updateResumeUseCaseProvider);
  return TemplateSelectionViewModel(ref, getResume, updateResume);
});
