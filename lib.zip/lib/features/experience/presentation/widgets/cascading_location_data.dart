/// Cascading mock dataset mapping Countries -> States -> Cities.
class CascadingLocationData {
  static const Map<String, Map<String, List<String>>> kCascadingLocationMap = {
    'India': {
      'Karnataka': ['Bengaluru', 'Mysuru', 'Hubballi', 'Mangaluru'],
      'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Nashik'],
      'Telangana': ['Hyderabad', 'Warangal', 'Nizamabad'],
      'Delhi': ['New Delhi', 'North Delhi', 'South Delhi'],
      'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai'],
    },
    'United States': {
      'California': ['San Francisco', 'Los Angeles', 'San Jose', 'San Diego'],
      'Texas': ['Austin', 'Houston', 'Dallas', 'San Antonio'],
      'New York': ['New York City', 'Buffalo', 'Albany'],
      'Washington': ['Seattle', 'Spokane', 'Tacoma'],
    },
    'United Kingdom': {
      'England': ['London', 'Manchester', 'Birmingham', 'Bristol'],
      'Scotland': ['Edinburgh', 'Glasgow', 'Aberdeen'],
    },
    'Canada': {
      'Ontario': ['Toronto', 'Ottawa', 'Hamilton'],
      'British Columbia': ['Vancouver', 'Victoria', 'Kelowna'],
    },
    'Japan': {
      'Tokyo Metropolis': ['Tokyo', 'Shinjuku', 'Shibuya'],
      'Osaka Prefecture': ['Osaka', 'Sakai'],
    },
  };

  static List<String> getCountries() {
    return kCascadingLocationMap.keys.toList();
  }

  static List<String> getStates(String? country) {
    if (country == null || !kCascadingLocationMap.containsKey(country)) {
      return kCascadingLocationMap.values
          .expand((m) => m.keys)
          .toSet()
          .toList();
    }
    return kCascadingLocationMap[country]!.keys.toList();
  }

  static List<String> getCities(String? country, String? state) {
    if (country != null && kCascadingLocationMap.containsKey(country)) {
      final countryMap = kCascadingLocationMap[country]!;
      if (state != null && countryMap.containsKey(state)) {
        return countryMap[state]!;
      }
      return countryMap.values.expand((element) => element).toSet().toList();
    }
    return kCascadingLocationMap.values
        .expand((m) => m.values.expand((c) => c))
        .toSet()
        .toList();
  }
}
