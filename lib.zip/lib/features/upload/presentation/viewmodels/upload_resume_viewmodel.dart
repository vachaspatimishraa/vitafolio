import 'package:flutter_riverpod/flutter_riverpod.dart';

class UploadResumeState {
  final bool isLoading;
  final String? selectedFileName;
  final String? selectedFileSize;
  final String? errorMessage;

  const UploadResumeState({
    this.isLoading = false,
    this.selectedFileName,
    this.selectedFileSize,
    this.errorMessage,
  });

  UploadResumeState copyWith({
    bool? isLoading,
    String? selectedFileName,
    String? selectedFileSize,
    String? errorMessage,
  }) {
    return UploadResumeState(
      isLoading: isLoading ?? this.isLoading,
      selectedFileName: selectedFileName ?? this.selectedFileName,
      selectedFileSize: selectedFileSize ?? this.selectedFileSize,
      errorMessage: errorMessage,
    );
  }
}

class UploadResumeViewModel extends StateNotifier<UploadResumeState> {
  UploadResumeViewModel() : super(const UploadResumeState());

  void selectMockFile(String name, String size) {
    state = state.copyWith(
      selectedFileName: name,
      selectedFileSize: size,
      errorMessage: null,
    );
  }

  void clearSelectedFile() {
    state = const UploadResumeState();
  }

  void setLoading(bool loading) {
    state = state.copyWith(isLoading: loading);
  }
}

final uploadResumeViewModelProvider =
    StateNotifierProvider<UploadResumeViewModel, UploadResumeState>((ref) {
  return UploadResumeViewModel();
});
