import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:vitafolio/app/constants/app_spacing.dart';
import 'package:vitafolio/app/router.dart';
import 'package:vitafolio/features/review_resume/presentation/viewmodels/review_resume_viewmodel.dart';
import 'package:vitafolio/features/review_resume/presentation/widgets/completion_progress_card.dart';
import 'package:vitafolio/features/review_resume/presentation/widgets/footer_action_bar.dart';
import 'package:vitafolio/features/review_resume/presentation/widgets/missing_section_card.dart';
import 'package:vitafolio/features/review_resume/presentation/widgets/resume_preview_card.dart';
import 'package:vitafolio/features/review_resume/presentation/widgets/resume_progress_stepper.dart';
import 'package:vitafolio/features/review_resume/presentation/widgets/resume_section_tile.dart';

/// Review & Generate Resume Screen Page (Step 9 of 9).
class ReviewResumePage extends ConsumerWidget {
  const ReviewResumePage({super.key});

  void _handlePrevious(BuildContext context) {
    if (Navigator.of(context).canPop()) {
      context.pop();
    } else {
      context.go(AppRoutes.languages);
    }
  }

  Future<void> _handleGenerateResume(BuildContext context, WidgetRef ref) async {
    final bytes = await ref.read(reviewResumeViewModelProvider.notifier).generateResume();
    if (!context.mounted) return;
    
    if (bytes != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Resume generated successfully! Previews available in Preview mode.'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  void _handlePreview(BuildContext context) {
    context.push(AppRoutes.preview);
  }

  void _handleEditSection(BuildContext context, WidgetRef ref, String sectionTitle, String route) {
    ref.read(reviewResumeViewModelProvider.notifier).selectSection(sectionTitle);
    context.push(route);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final state = ref.watch(reviewResumeViewModelProvider);

    ref.listen(reviewResumeViewModelProvider.select((s) => s.errorMessage), (prev, next) {
      if (next != null && next.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(next), backgroundColor: colorScheme.error),
        );
      }
    });

    final missingSections = state.sections.where((s) => !s.isCompleted).toList();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => _handlePrevious(context),
        ),
        title: const Text(
          'Review & Generate',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: colorScheme.surface,
        scrolledUnderElevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Divider(
            height: 1,
            color: colorScheme.outlineVariant.withValues(alpha: 0.5),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Progress Stepper (Step 9 of 9 - 100%)
            const ResumeProgressStepper(currentStepIndex: 8),

            // Scrollable Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(AppSpacing.lg),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header Section
                    Text(
                      'Review Your Resume',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      'Review your details, edit any section, and generate your high-resolution ATS-optimized resume.',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.lg),

                    // Resume Preview Card
                    ResumePreviewCard(
                      templateName: state.templateName,
                      atsFriendly: state.isAtsFriendly,
                      onPreview: () => _handlePreview(context),
                    ),
                    const SizedBox(height: AppSpacing.md),

                    // Completion Progress Card
                    CompletionProgressCard(
                      completedSections: state.completedSections,
                      totalSections: state.totalSections,
                      percentage: state.completionPercentage,
                    ),
                    const SizedBox(height: AppSpacing.lg),

                    // Missing Sections Warnings (Conditional)
                    if (missingSections.isNotEmpty) ...[
                      Text(
                        'Action Required',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.error,
                        ),
                      ),
                      const SizedBox(height: AppSpacing.xs),
                      ...missingSections.map(
                        (missing) => Padding(
                          padding: const EdgeInsets.only(bottom: AppSpacing.xs),
                          child: MissingSectionCard(
                            title: 'Missing ${missing.title}',
                            description: 'Add your ${missing.title.toLowerCase()} to complete your profile.',
                            onTap: () => _handleEditSection(
                                context, ref, missing.title, missing.route),
                          ),
                        ),
                      ),
                      const SizedBox(height: AppSpacing.md),
                    ],

                    // Section Tiles
                    Text(
                      'Resume Sections',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    ...state.sections.map(
                      (section) => ResumeSectionTile(
                        title: section.title,
                        completed: section.isCompleted,
                        onEdit: () => _handleEditSection(
                            context, ref, section.title, section.route),
                      ),
                    ),

                    const SizedBox(height: AppSpacing.xl),
                  ],
                ),
              ),
            ),

            // Sticky Bottom Action Footer
            FooterActionBar(
              onPrevious: () => _handlePrevious(context),
              onGenerate: () => _handleGenerateResume(context, ref),
              isGenerateEnabled: !state.isGenerating,
            ),
          ],
        ),
      ),
    );
  }
}
