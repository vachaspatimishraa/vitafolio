import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vitafolio/features/resume/domain/usecases/calculate_resume_completion.dart';
import 'package:vitafolio/features/resume/domain/usecases/generate_resume_pdf.dart';
import 'package:vitafolio/features/resume/domain/usecases/get_resume.dart';
import 'package:vitafolio/features/resume/domain/usecases/validate_resume.dart';
import 'package:vitafolio/features/resume/presentation/providers/resume_domain_providers.dart';

class SectionStatus {
  final String title;
  final String route;
  final bool isCompleted;

  const SectionStatus({
    required this.title,
    required this.route,
    required this.isCompleted,
  });
}

class ReviewResumeState {
  final String templateName;
  final bool isAtsFriendly;
  final int completedSections;
  final int totalSections;
  final double completionPercentage;
  final List<SectionStatus> sections;
  final bool isGenerating;
  final String? selectedSection;
  final bool isLoading;
  final String? errorMessage;

  const ReviewResumeState({
    this.templateName = 'Modern Professional',
    this.isAtsFriendly = true,
    this.completedSections = 0,
    this.totalSections = 9,
    this.completionPercentage = 0.0,
    this.sections = const [
      SectionStatus(title: 'Document Title', route: '/templates', isCompleted: false),
      SectionStatus(title: 'Template Selection', route: '/templates', isCompleted: false),
      SectionStatus(title: 'Personal Details', route: '/personal', isCompleted: false),
      SectionStatus(title: 'Professional Summary', route: '/summary', isCompleted: false),
      SectionStatus(title: 'Work Experience', route: '/experience', isCompleted: false),
      SectionStatus(title: 'Education', route: '/education', isCompleted: false),
      SectionStatus(title: 'Technical Skills', route: '/skills', isCompleted: false),
      SectionStatus(title: 'Certifications', route: '/certifications', isCompleted: false),
      SectionStatus(title: 'Languages', route: '/languages', isCompleted: false),
    ],
    this.isGenerating = false,
    this.selectedSection,
    this.isLoading = false,
    this.errorMessage,
  });

  ReviewResumeState copyWith({
    String? templateName,
    bool? isAtsFriendly,
    int? completedSections,
    int? totalSections,
    double? completionPercentage,
    List<SectionStatus>? sections,
    bool? isGenerating,
    String? selectedSection,
    bool? isLoading,
    String? errorMessage,
  }) {
    return ReviewResumeState(
      templateName: templateName ?? this.templateName,
      isAtsFriendly: isAtsFriendly ?? this.isAtsFriendly,
      completedSections: completedSections ?? this.completedSections,
      totalSections: totalSections ?? this.totalSections,
      completionPercentage: completionPercentage ?? this.completionPercentage,
      sections: sections ?? this.sections,
      isGenerating: isGenerating ?? this.isGenerating,
      selectedSection: selectedSection ?? this.selectedSection,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage,
    );
  }
}

class ReviewResumeViewModel extends StateNotifier<ReviewResumeState> {
  final Ref _ref;
  final GetResume _getResume;
  final CalculateResumeCompletion _calculateCompletion;
  final ValidateResume _validateResume;
  final GenerateResumePdf _generatePdf;

  ReviewResumeViewModel(
    this._ref,
    this._getResume,
    this._calculateCompletion,
    this._validateResume,
    this._generatePdf,
  ) : super(const ReviewResumeState()) {
    _load();
  }

  Future<void> _load() async {
    final activeId = _ref.read(activeResumeIdProvider);
    if (activeId == null) return;

    state = state.copyWith(isLoading: true);
    try {
      final resume = await _getResume(activeId);
      if (resume != null) {
        final progress = _calculateCompletion(resume);
        final completedCount = _calculateCompletion.completedSections(resume);
        final total = _calculateCompletion.totalSections();

        // Map 9 section statuses dynamically based on exact domain evaluation rules
        final updatedSections = state.sections.map((section) {
          bool isCompleted = false;
          switch (section.title) {
            case 'Document Title':
              isCompleted = resume.title.trim().isNotEmpty;
              break;
            case 'Template Selection':
              isCompleted = resume.selectedTemplateId.value.trim().isNotEmpty;
              break;
            case 'Personal Details':
              isCompleted = resume.personalDetails != null &&
                  resume.personalDetails!.fullName.trim().isNotEmpty &&
                  resume.personalDetails!.email.trim().isNotEmpty &&
                  resume.personalDetails!.phoneNumber.trim().isNotEmpty;
              break;
            case 'Professional Summary':
              isCompleted = resume.summary != null && resume.summary!.summaryText.trim().isNotEmpty;
              break;
            case 'Work Experience':
              isCompleted = resume.experiences.isNotEmpty &&
                  resume.experiences.every((exp) => exp.jobTitle.trim().isNotEmpty && exp.company.trim().isNotEmpty);
              break;
            case 'Education':
              isCompleted = resume.educations.isNotEmpty &&
                  resume.educations.every((edu) => edu.degree.trim().isNotEmpty && edu.institution.trim().isNotEmpty);
              break;
            case 'Technical Skills':
              isCompleted = resume.skills.isNotEmpty &&
                  resume.skills.every((s) => s.name.trim().isNotEmpty);
              break;
            case 'Certifications':
              isCompleted = resume.certifications.isNotEmpty &&
                  resume.certifications.every((c) => c.name.trim().isNotEmpty && c.organization.trim().isNotEmpty);
              break;
            case 'Languages':
              isCompleted = resume.languages.isNotEmpty &&
                  resume.languages.every((l) => l.name.trim().isNotEmpty && l.proficiencyLevel.trim().isNotEmpty);
              break;
          }
          return SectionStatus(
            title: section.title,
            route: section.route,
            isCompleted: isCompleted,
          );
        }).toList();

        state = state.copyWith(
          templateName: _getTemplateDisplayName(resume.selectedTemplateId.value),
          completionPercentage: progress,
          completedSections: completedCount,
          totalSections: total,
          sections: updatedSections,
          isLoading: false,
        );
      } else {
        state = state.copyWith(isLoading: false);
      }
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to load resume for review',
      );
    }
  }

  String _getTemplateDisplayName(String templateId) {
    switch (templateId) {
      case 'modern_clean':
        return 'Modern Clean';
      case 'prof_corp':
        return 'Professional Corporate';
      case 'minimal_elegant':
        return 'Minimal Elegant';
      case 'executive':
        return 'Executive';
      case 'creative':
        return 'Creative';
      case 'ats_friendly':
        return 'ATS Friendly';
      default:
        return 'Modern Professional';
    }
  }

  void selectSection(String sectionTitle) {
    state = state.copyWith(selectedSection: sectionTitle);
  }

  void setGenerating(bool generating) {
    state = state.copyWith(isGenerating: generating);
  }

  Future<List<int>?> generateResume() async {
    final activeId = _ref.read(activeResumeIdProvider);
    if (activeId == null) return null;

    state = state.copyWith(isGenerating: true);
    try {
      final resume = await _getResume(activeId);
      if (resume != null) {
        final failures = _validateResume(resume);
        if (failures.isNotEmpty) {
          state = state.copyWith(
            isGenerating: false,
            errorMessage: 'Please complete required sections: ${failures.map((f) => f.message).join(', ')}',
          );
          return null;
        }
        final bytes = await _generatePdf(resume);
        state = state.copyWith(isGenerating: false);
        return bytes;
      }
      state = state.copyWith(isGenerating: false);
      return null;
    } catch (e) {
      state = state.copyWith(
        isGenerating: false,
        errorMessage: 'Failed to generate resume PDF',
      );
      return null;
    }
  }
}

final reviewResumeViewModelProvider = StateNotifierProvider.autoDispose<
    ReviewResumeViewModel, ReviewResumeState>((ref) {
  ref.watch(activeResumeIdProvider);
  final getResume = ref.watch(getResumeUseCaseProvider);
  final calculateCompletion =
      ref.watch(calculateResumeCompletionUseCaseProvider);
  final validateResume = ref.watch(validateResumeUseCaseProvider);
  final generatePdf = ref.watch(generateResumePdfUseCaseProvider);
  return ReviewResumeViewModel(
    ref,
    getResume,
    calculateCompletion,
    validateResume,
    generatePdf,
  );
});
