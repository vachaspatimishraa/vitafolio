import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vitafolio/core/database/database_provider.dart';
import 'package:vitafolio/features/resume/data/datasources/resume_local_datasource.dart';
import 'package:vitafolio/features/resume/data/repositories/resume_repository_impl.dart';
import 'package:vitafolio/features/resume/domain/entities/resume.dart';
import 'package:vitafolio/features/resume/domain/repositories/resume_repository.dart';
import 'package:vitafolio/features/resume/domain/services/resume_completion_calculator.dart';
import 'package:vitafolio/features/resume/domain/services/resume_completion_calculator_impl.dart';
import 'package:vitafolio/features/resume/domain/services/resume_parser.dart';
import 'package:vitafolio/features/resume/domain/services/resume_pdf_generator.dart';
import 'package:vitafolio/features/resume/domain/services/resume_validator.dart';
import 'package:vitafolio/features/resume/domain/services/resume_validator_impl.dart';
import 'package:vitafolio/features/resume/domain/usecases/calculate_resume_completion.dart';
import 'package:vitafolio/features/resume/domain/usecases/create_resume.dart';
import 'package:vitafolio/features/resume/domain/usecases/delete_resume.dart';
import 'package:vitafolio/features/resume/domain/usecases/generate_resume_pdf.dart';
import 'package:vitafolio/features/resume/domain/usecases/get_all_resumes.dart';
import 'package:vitafolio/features/resume/domain/usecases/get_resume.dart';
import 'package:vitafolio/features/resume/domain/usecases/parse_resume_file.dart';
import 'package:vitafolio/features/resume/domain/usecases/update_resume.dart';
import 'package:vitafolio/features/resume/domain/usecases/validate_resume.dart';
import 'package:vitafolio/features/resume/domain/value_objects/resume_id.dart';
import 'package:vitafolio/features/resume/domain/value_objects/template_id.dart';

// Service Contracts Placeholders
class DefaultResumeParser implements ResumeParser {
  @override
  Future<Resume> parseFile(String filePath) async {
    return Resume(
      id: const ResumeId('parsed-file'),
      title: 'Parsed Resume',
      selectedTemplateId: const TemplateId('tmpl-modern'),
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  @override
  Future<Resume> parseText(String rawText) async {
    return Resume(
      id: const ResumeId('parsed-text'),
      title: 'Parsed Resume Text',
      selectedTemplateId: const TemplateId('tmpl-modern'),
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }
}

class DefaultResumePdfGenerator implements ResumePdfGenerator {
  @override
  Future<List<int>> generatePdf(Resume resume) async {
    return [1, 2, 3];
  }

  @override
  Future<List<int>> generatePreview(Resume resume) async {
    return [1, 2];
  }
}

final resumeLocalDataSourceProvider = Provider<ResumeLocalDataSource>((ref) {
  final isar = ref.watch(isarProvider);
  return ResumeLocalDataSourceImpl(isar);
});

final resumeDomainParserProvider = Provider<ResumeParser>((ref) {
  return DefaultResumeParser();
});

final resumeDomainPdfGeneratorProvider = Provider<ResumePdfGenerator>((ref) {
  return DefaultResumePdfGenerator();
});

final resumeDomainValidatorProvider = Provider<ResumeValidator>((ref) {
  return const ResumeValidatorImpl();
});

final resumeDomainCompletionCalculatorProvider = Provider<ResumeCompletionCalculator>((ref) {
  return const ResumeCompletionCalculatorImpl();
});

final cleanResumeRepositoryProvider = Provider<ResumeRepository>((ref) {
  return ResumeRepositoryImpl(
    localDataSource: ref.watch(resumeLocalDataSourceProvider),
    parser: ref.watch(resumeDomainParserProvider),
    pdfGenerator: ref.watch(resumeDomainPdfGeneratorProvider),
  );
});

final createResumeUseCaseProvider = Provider<CreateResume>((ref) {
  return CreateResume(ref.watch(cleanResumeRepositoryProvider));
});

final updateResumeUseCaseProvider = Provider<UpdateResume>((ref) {
  return UpdateResume(ref.watch(cleanResumeRepositoryProvider));
});

final deleteResumeUseCaseProvider = Provider<DeleteResume>((ref) {
  return DeleteResume(ref.watch(cleanResumeRepositoryProvider));
});

final getResumeUseCaseProvider = Provider<GetResume>((ref) {
  return GetResume(ref.watch(cleanResumeRepositoryProvider));
});

final getAllResumesUseCaseProvider = Provider<GetAllResumes>((ref) {
  return GetAllResumes(ref.watch(cleanResumeRepositoryProvider));
});

final parseResumeFileUseCaseProvider = Provider<ParseResumeFile>((ref) {
  return ParseResumeFile(ref.watch(resumeDomainParserProvider));
});

final generateResumePdfUseCaseProvider = Provider<GenerateResumePdf>((ref) {
  return GenerateResumePdf(ref.watch(resumeDomainPdfGeneratorProvider));
});

final validateResumeUseCaseProvider = Provider<ValidateResume>((ref) {
  return ValidateResume(ref.watch(resumeDomainValidatorProvider));
});

final calculateResumeCompletionUseCaseProvider = Provider<CalculateResumeCompletion>((ref) {
  return CalculateResumeCompletion(ref.watch(resumeDomainCompletionCalculatorProvider));
});

/// Provider to track the ID of the resume currently being built/edited.
final activeResumeIdProvider = StateProvider<ResumeId?>((ref) => null);
