import 'package:vitafolio/features/resume/domain/entities/resume.dart';
import 'package:vitafolio/features/resume/domain/failures/resume_failure.dart';
import 'package:vitafolio/features/resume/domain/services/resume_validator.dart';

/// Pure Domain Implementation of [ResumeValidator].
/// Evaluates business rules and validation constraints on a [Resume] entity across all 9 builder sections.
class ResumeValidatorImpl implements ResumeValidator {
  const ResumeValidatorImpl();

  @override
  bool isComplete(Resume resume) {
    return validate(resume).isEmpty;
  }

  @override
  List<ResumeFailure> validate(Resume resume) {
    final failures = <ResumeFailure>[];

    // 1. Resume Document Title
    if (resume.title.trim().isEmpty) {
      failures.add(const ValidationFailure('Resume document title is required'));
    }

    // 2. Selected Template
    if (resume.selectedTemplateId.value.trim().isEmpty) {
      failures.add(const ValidationFailure('A resume template must be selected'));
    }

    // 3. Personal Details Validation
    final details = resume.personalDetails;
    if (details == null || details.fullName.trim().isEmpty) {
      failures.add(const ValidationFailure('Full name is required in Personal Details'));
    } else if (details.email.trim().isEmpty || !details.email.contains('@')) {
      failures.add(const ValidationFailure('Valid email address is required in Personal Details'));
    } else if (details.phoneNumber.trim().isEmpty) {
      failures.add(const ValidationFailure('Phone number is required in Personal Details'));
    }

    // 4. Professional Summary Validation
    final summary = resume.summary;
    if (summary == null || summary.summaryText.trim().isEmpty) {
      failures.add(const ValidationFailure('Professional Summary text cannot be empty'));
    }

    // 5. Work Experience Validation
    if (resume.experiences.isEmpty) {
      failures.add(const ValidationFailure('At least one Work Experience entry is required'));
    } else {
      for (final exp in resume.experiences) {
        if (exp.jobTitle.trim().isEmpty || exp.company.trim().isEmpty) {
          failures.add(ValidationFailure('Job Title and Company are required for Experience entry (${exp.id})'));
        }
      }
    }

    // 6. Education Validation
    if (resume.educations.isEmpty) {
      failures.add(const ValidationFailure('At least one Education entry is required'));
    } else {
      for (final edu in resume.educations) {
        if (edu.degree.trim().isEmpty || edu.institution.trim().isEmpty) {
          failures.add(ValidationFailure('Degree and Institution are required for Education entry (${edu.id})'));
        }
      }
    }

    // 7. Skills Validation
    if (resume.skills.isEmpty) {
      failures.add(const ValidationFailure('At least one Skill entry is required'));
    } else {
      for (final skill in resume.skills) {
        if (skill.name.trim().isEmpty) {
          failures.add(ValidationFailure('Skill name cannot be empty (${skill.id})'));
        }
      }
    }

    // 8. Certifications Validation (Optional section, but entries must be valid if present)
    for (final cert in resume.certifications) {
      if (cert.name.trim().isEmpty || cert.organization.trim().isEmpty) {
        failures.add(ValidationFailure('Certification Name and Organization are required (${cert.id})'));
      }
    }

    // 9. Languages Validation (Optional section, but entries must be valid if present)
    for (final lang in resume.languages) {
      if (lang.name.trim().isEmpty || lang.proficiencyLevel.trim().isEmpty) {
        failures.add(ValidationFailure('Language Name and Proficiency Level are required (${lang.id})'));
      }
    }

    return failures;
  }
}
