import 'package:flutter/material.dart';
import 'package:vitafolio/features/personal_details/presentation/widgets/hybrid_search_dropdown.dart';

/// Form containing all Personal Details input fields.
class PersonalDetailsForm extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController fullNameController;
  final TextEditingController jobRoleController;
  final TextEditingController phoneController;
  final TextEditingController emailController;
  final TextEditingController linkedinController;
  final TextEditingController githubController;
  final TextEditingController websiteController;
  final String? selectedCity;
  final String? selectedState;
  final ValueChanged<String> onCityChanged;
  final ValueChanged<String> onStateChanged;

  static const List<String> kMockCities = [
    'New York',
    'San Francisco',
    'Los Angeles',
    'Chicago',
    'Austin',
    'Seattle',
    'Boston',
    'Denver',
    'London',
    'Toronto',
    'Berlin',
    'Sydney',
    'Tokyo',
    'Mumbai',
    'Bangalore',
  ];

  static const List<String> kMockStates = [
    'California',
    'New York',
    'Texas',
    'Washington',
    'Illinois',
    'Massachusetts',
    'Colorado',
    'Florida',
    'Ontario',
    'Bavaria',
    'New South Wales',
    'Maharashtra',
    'Karnataka',
  ];

  const PersonalDetailsForm({
    super.key,
    required this.formKey,
    required this.fullNameController,
    required this.jobRoleController,
    required this.phoneController,
    required this.emailController,
    required this.linkedinController,
    required this.githubController,
    required this.websiteController,
    required this.selectedCity,
    required this.selectedState,
    required this.onCityChanged,
    required this.onStateChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Full Name *
          TextFormField(
            controller: fullNameController,
            decoration: InputDecoration(
              labelText: 'Full Name *',
              hintText: 'e.g. John Doe',
              prefixIcon: const Icon(Icons.person_outline),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            textInputAction: TextInputAction.next,
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return 'Full name is required';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),

          // Job Role *
          TextFormField(
            controller: jobRoleController,
            decoration: InputDecoration(
              labelText: 'Job Role *',
              hintText: 'Flutter Developer',
              prefixIcon: const Icon(Icons.work_outline),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            textInputAction: TextInputAction.next,
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return 'Job role is required';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),

          // Phone Number * & Email Address * Row / Column
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    labelText: 'Phone Number *',
                    hintText: '+1 (555) 000-0000',
                    prefixIcon: const Icon(Icons.phone_outlined),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  textInputAction: TextInputAction.next,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Phone number is required';
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    labelText: 'Email Address *',
                    hintText: 'john@example.com',
                    prefixIcon: const Icon(Icons.email_outlined),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  textInputAction: TextInputAction.next,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Email is required';
                    }
                    return null;
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // City * & State * Hybrid Search Dropdowns
          Row(
            children: [
              Expanded(
                child: HybridSearchDropdown(
                  label: 'City *',
                  initialValue: selectedCity,
                  items: kMockCities,
                  onChanged: onCityChanged,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: HybridSearchDropdown(
                  label: 'State *',
                  initialValue: selectedState,
                  items: kMockStates,
                  onChanged: onStateChanged,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Social Links Section Header
          Text(
            'Social & Online Profiles',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
          ),
          const SizedBox(height: 12),

          // LinkedIn
          TextFormField(
            controller: linkedinController,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(
              labelText: 'LinkedIn Profile',
              hintText: 'https://linkedin.com/in/username',
              prefixIcon: const Icon(Icons.link_outlined),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 16),

          // GitHub
          TextFormField(
            controller: githubController,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(
              labelText: 'GitHub Profile',
              hintText: 'https://github.com/username',
              prefixIcon: const Icon(Icons.code_outlined),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 16),

          // Portfolio / Website
          TextFormField(
            controller: websiteController,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(
              labelText: 'Portfolio / Website',
              hintText: 'https://portfolio.com',
              prefixIcon: const Icon(Icons.language_outlined),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            textInputAction: TextInputAction.done,
          ),
        ],
      ),
    );
  }
}
